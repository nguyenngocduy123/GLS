Copyright (C) 2018 Singapore Institute of Manufacturing Technology - All Rights Reserved

Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential

NOTICE: All information contained herein is, and remains the property of
SIMTech and its suppliers, if any. The intellectual and technical concepts
contained herein are proprietary to SIMTech and its suppliers and may be
covered by Singapore and Foreign Patents, patents in process, and are
protected by trade secret or copyright law. Dissemination of this information
or reproduction of this material is strictly forbidden unless prior written
permission is obtained from SIMTech Incorporated.
