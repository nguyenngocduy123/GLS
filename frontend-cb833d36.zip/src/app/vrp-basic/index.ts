
export * from './vrp-basic.module';
