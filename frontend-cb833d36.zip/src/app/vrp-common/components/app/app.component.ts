import { Component } from '@angular/core';

@Component({
    selector: 'vrp-app',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {

    constructor() { }
}
