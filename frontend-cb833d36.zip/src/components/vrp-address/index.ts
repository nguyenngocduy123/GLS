export * from './vrp-address.module';
