export * from './vrp-dialog.module';
