export * from './vrp-search-select.module';
