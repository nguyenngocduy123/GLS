export * from './vrp-size.module';
