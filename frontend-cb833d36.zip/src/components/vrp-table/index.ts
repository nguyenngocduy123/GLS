export * from './vrp-table.module';
