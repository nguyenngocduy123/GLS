export const environment: { production: boolean, backEndUrl: string } = {
    production: true,
    backEndUrl: '',
};
